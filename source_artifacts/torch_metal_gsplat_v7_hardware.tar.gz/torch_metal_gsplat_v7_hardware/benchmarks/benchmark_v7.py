from __future__ import annotations

import argparse
import time

import torch

from torch_gsplat_bridge_v7 import RasterConfig, rasterize_projected_gaussians


def sync() -> None:
    if torch.backends.mps.is_available():
        torch.mps.synchronize()


def make_case(B, G, H, W, device):
    torch.manual_seed(0)
    means2d = torch.rand(B, G, 2, device=device) * torch.tensor([W - 1, H - 1], device=device)
    sigma = 1.0 + 4.0 * torch.rand(B, G, device=device)
    theta = 2.0 * torch.pi * torch.rand(B, G, device=device)
    ct = torch.cos(theta); st = torch.sin(theta)
    a = ct * ct / (sigma * sigma) + st * st / (sigma * sigma)
    b = torch.zeros_like(a)
    c = a.clone()
    conics = torch.stack([a, b, c], dim=-1)
    colors = torch.rand(B, G, 3, device=device)
    opacities = 0.2 + 0.7 * torch.rand(B, G, device=device)
    depths = torch.rand(B, G, device=device)
    return means2d, conics, colors, opacities, depths


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--height', type=int, default=1024)
    p.add_argument('--width', type=int, default=1024)
    p.add_argument('--gaussians', type=int, default=8192)
    p.add_argument('--batch-size', type=int, default=1)
    p.add_argument('--iters', type=int, default=3)
    p.add_argument('--backward', action='store_true')
    args = p.parse_args()
    if not torch.backends.mps.is_available():
        raise SystemExit('MPS is not available.')
    device = torch.device('mps')
    cfg = RasterConfig(height=args.height, width=args.width)
    times = []
    for _ in range(args.iters):
        means2d, conics, colors, opacities, depths = make_case(args.batch_size, args.gaussians, args.height, args.width, device)
        if args.backward:
            means2d.requires_grad_(True); conics.requires_grad_(True); colors.requires_grad_(True); opacities.requires_grad_(True)
        sync(); t0 = time.perf_counter()
        out = rasterize_projected_gaussians(means2d, conics, colors, opacities, depths, cfg)
        if args.backward:
            out.square().mean().backward()
        sync(); times.append((time.perf_counter() - t0) * 1000.0)
    print({'mean_ms': sum(times)/len(times), 'min_ms': min(times), 'max_ms': max(times)})


if __name__ == '__main__':
    main()
