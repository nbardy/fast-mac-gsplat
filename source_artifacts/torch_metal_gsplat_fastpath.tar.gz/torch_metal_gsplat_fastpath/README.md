# torch_metal_gsplat_fastpath

Torch-first, Metal-backed Gaussian rasterizer fast path for Apple Silicon.

## Design goals

- Keep the Python training loop in **PyTorch**.
- Use **Metal kernels** for the renderer hot path.
- Minimize memory during training by saving only compact tile bins, **not** dense `G x H x W` activations.
- Keep backward differentiable via **recompute**, not via storing per-pixel alpha / transmittance graphs.

## Fast path pipeline

1. Python wrapper sorts Gaussians by depth **outside** the custom op.
2. `count_tiles` computes SnugBox-style bounds and exact tile intersections.
3. `tile_counts -> tile_offsets` uses `torch.cumsum` on MPS.
4. `emit_binned_ids` writes sorted-rank Gaussian IDs into per-tile bins via atomic cursors.
5. `tile_sort_render_forward` loads one tile's bin into threadgroup memory, bitonic-sorts the IDs, and immediately renders the tile.
6. `tile_sort_render_backward` repeats the same local sort, recomputes the forward alpha chain, then reverse-scans it for gradients.

## Saved activations

Forward returns:

- `image`: `[H, W, 3]`
- `tile_counts`: `[T]`
- `tile_offsets`: `[T + 1]`
- `binned_ids`: `[N]`

That is the entire saved state for backward, plus the sorted inputs. There is no saved dense `alpha`, `weights`, `dx`, or `power` volume.

## Differentiability

Gradients are implemented for:

- `means2d`
- `conics`
- `colors`
- `opacities`

Depth is treated as a piecewise-constant ordering key, so gradients w.r.t. `depths` are zero.

## Important caveat

This fast path uses a compile-time threadgroup list cap of **4096 splats per tile**. If a tile exceeds that count, the op throws and you should:

- increase `max_tile_pairs` only if you also raise the shader compile-time cap,
- reduce splat density,
- or add a slower overflow fallback (for example a global pair-sort path).

## Why this is faster than the earlier bridge

- No MLX in the hot path.
- No global pair sort on the common path.
- Tile bins are grouped once, then sorted **locally** in threadgroup memory.
- Backward recomputes local alpha instead of storing huge activations.

## Build

Build on macOS with Xcode command line tools and a matching PyTorch version:

```bash
python setup.py build_ext --inplace
```

Because this extension uses **internal PyTorch MPS headers**, engineering should pin the PyTorch version used for the Mac backend.
