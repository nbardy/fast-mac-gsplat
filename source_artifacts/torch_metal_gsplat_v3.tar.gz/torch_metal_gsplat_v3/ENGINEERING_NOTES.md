# Engineering notes for v3

## What changed from the earlier fastpath

- uses 256-thread tile groups instead of 1024-thread groups
- compiles around a smaller shared-ID cap (`GSP_FAST_CAP = 2048`) to improve occupancy
- keeps the fast path exact for normal tiles and adds a slow overflow path instead of hard-failing
- stages Gaussian parameters into threadgroup memory in chunks to cut repeated device-memory reads
- keeps forward exact front-to-back alpha compositing
- keeps backward low-memory by recomputing alpha/transmittance instead of storing dense activations
- reduces backward global atomics by doing per-Gaussian reductions inside each tile threadgroup
- treats Torch `[G,3]` tensors as packed `float*`, not `float3*`

## Why keep Torch ops for sort / scan

The wrapper still uses Torch MPS for:

- stable global depth sort (`torch.argsort(stable=True)`)
- prefix sum (`torch.cumsum`)
- rare overflow-tile ID sorting

That is deliberate. It keeps the hot raster kernels in Metal while using robust library primitives for global sort/scan.

## Expected fast path

1. Python sorts by detached depth.
2. Metal counts tile intersections with SnugBox + exact rectangle/ellipse test.
3. Torch computes tile offsets.
4. Metal emits compact tile bins of sorted-rank IDs.
5. Fast tiles local-sort in threadgroup memory and render.
6. Overflow tiles go through the slower overflow path.
7. Backward recomputes and does Gaussian-centric gradient reduction.

## Caveats

- still a projected 2D renderer, not a full 3D projection frontend
- still depends on internal PyTorch MPS Metal headers
- depth gradients remain zero because order is treated as piecewise constant
- this source bundle should be compiled and profiled on the target Mac before calling it production-ready
